# NEXORA — New Website

A fresh responsive website for NEXORA Creative Digital Studio.

## Included
- Premium dark responsive design
- Services and starting prices
- Concept portfolio cards (replace with real work before presenting them as client projects)
- About / studio principles section
- Project inquiry form that opens the visitor's email app
- Mobile navigation, subtle reveal animations, accessible reduced-motion support

## Run on your phone or computer
Open `index.html` in a browser to preview. For local development, use any simple static server.

## Publish with GitHub Pages
1. Download and extract the ZIP.
2. Review the files and replace any concept portfolio cards with real projects when available.
3. Upload `index.html`, `style.css`, `script.js`, and this README to a **new repository** or a dedicated folder/repository.
4. In GitHub, open **Settings → Pages**.
5. Select **Deploy from a branch**, choose `main` and `/ (root)`, then Save.
6. Wait for GitHub Pages to publish the site.

If publishing to a project URL such as `https://USERNAME.github.io/REPOSITORY/`, this site uses relative local asset paths, so it does not need a Next.js `basePath`.

## Important limitations
This is a static front-end website. The contact form prepares an email using `mailto:`; it does not save submissions to a database or send them in the background. Real client login, admin dashboard, persistent orders, automated PDF invoices, notifications, and online payments need a secure backend/database and payment provider integration. Do not collect payment credentials in this static site.
