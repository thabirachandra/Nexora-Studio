const menuToggle = document.getElementById("menuToggle");
const mainNav = document.getElementById("mainNav");

menuToggle?.addEventListener("click", () => {
  const open = mainNav.classList.toggle("open");
  menuToggle.setAttribute("aria-expanded", String(open));
  menuToggle.textContent = open ? "×" : "☰";
});

mainNav?.querySelectorAll("a").forEach(link => {
  link.addEventListener("click", () => {
    mainNav.classList.remove("open");
    menuToggle?.setAttribute("aria-expanded", "false");
    if (menuToggle) menuToggle.textContent = "☰";
  });
});

document.getElementById("year").textContent = new Date().getFullYear();

document.querySelectorAll("[data-service]").forEach(link => {
  link.addEventListener("click", () => {
    const select = document.getElementById("serviceSelect");
    if (select) select.value = link.dataset.service;
  });
});

document.querySelectorAll("[data-package]").forEach(link => {
  link.addEventListener("click", () => {
    const select = document.getElementById("serviceSelect");
    if (select) select.value = link.dataset.package === "Short-form edit" || link.dataset.package === "YouTube video" || link.dataset.package === "Cinematic edit" ? "Video Editing" : "";
  });
});

const observer = new IntersectionObserver(entries => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      entry.target.classList.add("visible");
      observer.unobserve(entry.target);
    }
  });
}, { threshold: 0.12 });
document.querySelectorAll(".service-card,.work-card,.price-card,.principles>div").forEach(el => {
  el.classList.add("reveal");
  observer.observe(el);
});

document.getElementById("projectForm")?.addEventListener("submit", event => {
  event.preventDefault();
  const form = event.currentTarget;
  const data = new FormData(form);
  const name = String(data.get("name") || "").trim();
  const contact = String(data.get("contact") || "").trim();
  const service = String(data.get("service") || "").trim();
  const budget = String(data.get("budget") || "Not sure yet");
  const timeline = String(data.get("timeline") || "Flexible");
  const details = String(data.get("details") || "").trim();

  if (!name || !contact || !service) {
    document.getElementById("formStatus").textContent = "Please complete your name, contact and service fields.";
    return;
  }

  const subject = encodeURIComponent(`NEXORA Project Request — ${service}`);
  const body = encodeURIComponent(
`Hello NEXORA,

I'd like to discuss a project.

Name: ${name}
Email / WhatsApp: ${contact}
Service: ${service}
Budget: ${budget}
Timeline: ${timeline}

Project details:
${details || "I will share more details during the discussion."}

Thank you.`
  );
  document.getElementById("formStatus").textContent = "Opening your email app with the request. Please review and send the email to submit it.";
  window.location.href = `mailto:nexora.studio064@gmail.com?subject=${subject}&body=${body}`;
});
